library("testthat")
test_check("jroreillyregression")
